export default function Page() {
  return (
    <main>
      <p>Welcome. Go to <a href='/report'>Report</a> to see the Google Sheet–style table that auto-aggregates daily metrics.</p>
    </main>
  )
}
