import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const url = new URL(req.url)
  const date = url.searchParams.get('date') // YYYY-MM-DD
  const whereDate = date ? `AND md.date::date = '${date}'` : ''
  const rows: any[] = await prisma.$queryRawUnsafe(`
    SELECT c.title as channel, md.date::date as date,
           md.views, md.watch_time_minutes as "watchTimeMinutes",
           md.avg_view_duration_seconds as "avdSeconds",
           md.est_revenue_global_usd as "grossUsd",
           COALESCE(us.us_usd,0) as "usUsd",
           nrd.net_after_network_usd as "netAfterNetworkUsd",
           nrd.net_after_tax_usd as "netAfterTaxUsd"
    FROM "MetricsDaily" md
    JOIN "Channel" c ON c.id = md.channel_id
    LEFT JOIN (
      SELECT date, channel_id, SUM(est_revenue_usd) as us_usd
      FROM "RevenueDailyCountry"
      WHERE country = 'US'
      GROUP BY date, channel_id
    ) us ON us.channel_id = md.channel_id AND us.date = md.date
    LEFT JOIN "NetRevenueDaily" nrd ON nrd.channel_id = md.channel_id AND nrd.date = md.date
    WHERE 1=1 ${whereDate}
    ORDER BY md.date DESC, c.title ASC;
  `)
  const header = ["Channel","Date","Views","WatchTimeMinutes","AVDSeconds","GrossUSD","USUSD","NetAfterNetworkUSD","NetAfterTaxUSD"]
  const lines = [header.join(",")]
  for (const r of rows) {
    const d = new Date(r.date).toISOString().slice(0,10)
    lines.push([r.channel, d, r.views, r.watchTimeMinutes, r.avdSeconds, r.grossUsd, r.usUsd, r.netAfterNetworkUsd, r.netAfterTaxUsd].join(","))
  }
  return new NextResponse(lines.join("\n"), { headers: { "Content-Type": "text/csv; charset=utf-8" } })
}
