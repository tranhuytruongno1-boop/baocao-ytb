import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { searchParams } = new URL(req.url)
  const from = searchParams.get('from')
  const to = searchParams.get('to')
  if (!from || !to) return NextResponse.json({ error: 'from/to required' }, { status: 400 })
  const channelId = Number(params.id)
  const daily = await prisma.$queryRawUnsafe(`
    SELECT md.date::date as date,
           md.views,
           md.watch_time_minutes as "watchTimeMinutes",
           md.avg_view_duration_seconds as "avdSeconds",
           md.est_revenue_global_usd as "grossUsd",
           COALESCE(us.us_usd, 0) as "usUsd",
           nrd.net_after_network_usd as "netAfterNetworkUsd",
           nrd.net_after_tax_usd as "netAfterTaxUsd"
    FROM "MetricsDaily" md
    LEFT JOIN (
      SELECT date, channel_id, SUM(est_revenue_usd) as us_usd
      FROM "RevenueDailyCountry"
      WHERE country = 'US'
      GROUP BY date, channel_id
    ) us ON us.channel_id = md.channel_id AND us.date = md.date
    LEFT JOIN "NetRevenueDaily" nrd ON nrd.channel_id = md.channel_id AND nrd.date = md.date
    WHERE md.channel_id = $1 AND md.date BETWEEN $2 AND $3
    ORDER BY md.date ASC;
  `, channelId, from, to)
  return NextResponse.json({ channelId, range: { from, to }, daily })
}
