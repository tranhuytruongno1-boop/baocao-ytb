export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'Inter, system-ui, -apple-system, Segoe UI, Roboto', background: '#fafafa' }}>
        <div style={{ maxWidth: 1200, margin: '24px auto', padding: 24 }}>
          <h1 style={{ fontSize: 28, fontWeight: 800, marginBottom: 8 }}>YT Analytics Portal</h1>
          <nav style={{ marginBottom: 16 }}>
            <a href='/' style={{ marginRight: 12 }}>Home</a>
            <a href='/report'>Report</a>
          </nav>
          {children}
        </div>
      </body>
    </html>
  )
}
