'use client'
import React, { useEffect, useMemo, useState } from 'react'

type Row = {
  date: string
  channel: string
  views: number
  watchTimeMinutes: number
  avdSeconds: number
  grossUsd: number
  usUsd: number
  netAfterNetworkUsd: number
  netAfterTaxUsd: number
}

export default function ReportPage() {
  const [rows, setRows] = useState<Row[]>([])
  const [q, setQ] = useState('')
  const [from, setFrom] = useState('2025-09-21')
  const [to, setTo] = useState('2025-09-30')
  const [channelId, setChannelId] = useState<number>(1)

  useEffect(() => {
    fetch(`/api/channels/${channelId}/metrics?from=${from}&to=${to}`)
      .then(r=>r.json())
      .then(data => {
        const out: Row[] = (data.daily || []).map((d: any) => ({
          date: d.date?.slice(0,10),
          channel: `Channel #${channelId}`,
          views: d.views, watchTimeMinutes: d.watchTimeMinutes, avdSeconds: d.avdSeconds,
          grossUsd: Number(d.grossUsd ?? 0),
          usUsd: Number(d.usUsd ?? 0),
          netAfterNetworkUsd: Number(d.netAfterNetworkUsd ?? 0),
          netAfterTaxUsd: Number(d.netAfterTaxUsd ?? 0),
        }))
        setRows(out)
      })
  }, [from, to, channelId])

  const filtered = useMemo(() => {
    const qq = q.toLowerCase()
    return rows.filter(r => r.channel.toLowerCase().includes(qq))
  }, [rows, q])

  const totals = useMemo(() => {
    const agg = (key: keyof Row) => filtered.reduce((a,b)=>a + Number(b[key] || 0), 0)
    return {
      views: agg('views'),
      watch: agg('watchTimeMinutes'),
      gross: agg('grossUsd'),
      us: agg('usUsd'),
      net: agg('netAfterTaxUsd'),
    }
  }, [filtered])

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <div>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>Bảng báo cáo kiểu Google Sheet</h2>
        <p style={{ opacity: 0.7 }}>Dữ liệu tự cập nhật hằng ngày (ETL lúc 06:00). Lọc theo ngày/kênh, có tổng dòng cuối giống Spreadsheet.</p>
      </div>

      <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr' }}>
        <input placeholder='Tìm kênh…' value={q} onChange={e=>setQ(e.target.value)} />
        <input type='date' value={from} onChange={e=>setFrom(e.target.value)} />
        <input type='date' value={to} onChange={e=>setTo(e.target.value)} />
        <select value={String(channelId)} onChange={e=>setChannelId(Number(e.target.value))}>
          <option value='1'>Channel #1</option>
        </select>
        <a href={`/api/exports/daily`} style={{ alignSelf:'center' }}>Export CSV hôm nay</a>
      </div>

      <div style={{ overflowX: 'auto', background: 'white', borderRadius: 12, border: '1px solid #eee' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              {['Date','Channel','Views','WatchTime(min)','AVD(s)','Gross $','US $','Net (after tax) $'].map(h => (
                <th key={h} style={{ textAlign:'left', borderBottom: '1px solid #ddd', padding: 8 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, idx) => (
              <tr key={idx} style={{ borderBottom: '1px solid #f0f0f0' }}>
                <td style={{ padding: 8 }}>{r.date}</td>
                <td style={{ padding: 8 }}>{r.channel}</td>
                <td style={{ padding: 8, textAlign:'right' }}>{r.views.toLocaleString()}</td>
                <td style={{ padding: 8, textAlign:'right' }}>{r.watchTimeMinutes.toLocaleString()}</td>
                <td style={{ padding: 8, textAlign:'right' }}>{r.avdSeconds.toLocaleString()}</td>
                <td style={{ padding: 8, textAlign:'right' }}>${r.grossUsd.toFixed(2)}</td>
                <td style={{ padding: 8, textAlign:'right' }}>${r.usUsd.toFixed(2)}</td>
                <td style={{ padding: 8, textAlign:'right' }}>${r.netAfterTaxUsd.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td style={{ padding: 8, fontWeight: 600 }}>Tổng</td>
              <td></td>
              <td style={{ padding: 8, textAlign:'right', fontWeight: 600 }}>{totals.views.toLocaleString()}</td>
              <td style={{ padding: 8, textAlign:'right', fontWeight: 600 }}>{totals.watch.toLocaleString()}</td>
              <td></td>
              <td style={{ padding: 8, textAlign:'right', fontWeight: 600 }}>${totals.gross.toFixed(2)}</td>
              <td style={{ padding: 8, textAlign:'right', fontWeight: 600 }}>${totals.us.toFixed(2)}</td>
              <td style={{ padding: 8, textAlign:'right', fontWeight: 600 }}>${totals.net.toFixed(2)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}
