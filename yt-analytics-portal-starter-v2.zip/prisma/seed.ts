import { prisma } from '../lib/prisma'

async function main() {
  const ch = await prisma.channel.upsert({
    where: { youtubeChannelId: 'demo-channel-1' },
    update: { title: 'Demo Channel 1' },
    create: { youtubeChannelId: 'demo-channel-1', title: 'Demo Channel 1' }
  })

  const start = new Date('2025-09-21')
  for (let i=0;i<10;i++){
    const d = new Date(start); d.setDate(d.getDate()+i)
    const views = 120000 + Math.floor(Math.random()*60000)
    const watch = Math.floor(views * 0.42)
    const avd = 24 + Math.floor(Math.random()*4)
    const gross = 190 + Math.random()*90
    const us = gross * 0.52
    const netAfterNetwork = gross * 0.8
    const netAfterTax = netAfterNetwork * 0.95

    await prisma.metricsDaily.upsert({
      where: { channelId_date: { channelId: ch.id, date: d } as any },
      update: { views, watchTimeMinutes: watch, avgViewDurationSeconds: avd, estRevenueGlobalUsd: gross, sourceTag: 'seed' },
      create: { channelId: ch.id, date: d, views, watchTimeMinutes: watch, avgViewDurationSeconds: avd, estRevenueGlobalUsd: gross, sourceTag: 'seed' }
    })

    await prisma.revenueDailyCountry.upsert({
      where: { channelId_date_country: { channelId: ch.id, date: d, country: 'US' } as any },
      update: { estRevenueUsd: us },
      create: { channelId: ch.id, date: d, country: 'US', estRevenueUsd: us }
    })

    await prisma.netRevenueDaily.upsert({
      where: { channelId_date: { channelId: ch.id, date: d } as any },
      update: { grossUsd: gross, grossUsUsd: us, networkSharePercent: 20, taxPercent: 5, netAfterNetworkUsd: netAfterNetwork, netAfterTaxUsd: netAfterTax },
      create: { channelId: ch.id, date: d, grossUsd: gross, grossUsUsd: us, networkSharePercent: 20, taxPercent: 5, netAfterNetworkUsd: netAfterNetwork, netAfterTaxUsd: netAfterTax }
    })
  }
  console.log('Seeded demo data. Open http://localhost:3000/report')
}
main().then(()=>process.exit(0)).catch(e=>{console.error(e);process.exit(1)})
