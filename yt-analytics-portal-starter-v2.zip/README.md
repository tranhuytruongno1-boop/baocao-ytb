# YT Analytics Portal — Sheet-style Report (Auto Daily)

A Next.js + Prisma starter that renders a **Google Sheet–like report** but with **automatic daily updates** from YouTube Analytics (stub included).

## Quickstart
```bash
docker compose up -d
pnpm install        # or npm i
cp .env.example .env.local
pnpm prisma migrate dev --name init
pnpm seed           # fill demo data
pnpm dev
```
Visit http://localhost:3000/report

## Auto Update
- Add real Google OAuth & YouTube Analytics calls in `lib/youtube.ts`.
- Schedule `jobs/dailyPull.ts` at 06:00 Asia/Bangkok (Vercel/Render/GitHub Actions).

## Export
- CSV endpoint: `/api/exports/daily?date=YYYY-MM-DD`
