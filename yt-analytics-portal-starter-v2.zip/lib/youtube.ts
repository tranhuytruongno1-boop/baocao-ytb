export async function getYTAnalytics(channelId: string, opts: { date: string, dimension?: 'country' }) {
  if (!opts.dimension) return { views: 1000, watchTime: 4500, avd: 270, grossUsd: 12.34 }
  return { countries: [ { country: 'US', revenueUsd: 6.78 }, { country: 'VN', revenueUsd: 0.42 } ] }
}
