import dayjs from 'dayjs'
import { prisma } from '@/lib/prisma'
import { getYTAnalytics } from '@/lib/youtube'

export async function runDailyPull(dateStr?: string) {
  const date = dateStr ?? dayjs().subtract(1,'day').format('YYYY-MM-DD')
  const channels = await prisma.channel.findMany({ where: { status: 'active' } })

  for (const ch of channels) {
    const base = await getYTAnalytics(ch.youtubeChannelId, { date })
    await prisma.metricsDaily.upsert({
      where: { channelId_date: { channelId: ch.id, date: new Date(date) } as any },
      update: {
        views: base.views, watchTimeMinutes: base.watchTime, avgViewDurationSeconds: base.avd,
        estRevenueGlobalUsd: base.grossUsd, sourceTag: 'yt-analytics'
      },
      create: {
        channelId: ch.id, date: new Date(date),
        views: base.views, watchTimeMinutes: base.watchTime, avgViewDurationSeconds: base.avd,
        estRevenueGlobalUsd: base.grossUsd, sourceTag: 'yt-analytics'
      }
    })

    const byCountry = await getYTAnalytics(ch.youtubeChannelId, { date, dimension: 'country' })
    let us = 0
    for (const row of byCountry.countries) {
      await prisma.revenueDailyCountry.upsert({
        where: { channelId_date_country: { channelId: ch.id, date: new Date(date), country: row.country } as any },
        update: { estRevenueUsd: row.revenueUsd },
        create: { channelId: ch.id, date: new Date(date), country: row.country, estRevenueUsd: row.revenueUsd }
      })
      if (row.country === 'US') us = row.revenueUsd
    }

    const gross = base.grossUsd as number
    const netAfterNetwork = gross * 0.8
    const netAfterTax = netAfterNetwork * 0.95
    await prisma.netRevenueDaily.upsert({
      where: { channelId_date: { channelId: ch.id, date: new Date(date) } as any },
      update: {
        grossUsd: gross, grossUsUsd: us, networkSharePercent: 20, taxPercent: 5,
        netAfterNetworkUsd: netAfterNetwork, netAfterTaxUsd: netAfterTax
      },
      create: {
        channelId: ch.id, date: new Date(date),
        grossUsd: gross, grossUsUsd: us, networkSharePercent: 20, taxPercent: 5,
        netAfterNetworkUsd: netAfterNetwork, netAfterTaxUsd: netAfterTax
      }
    })
  }
}

if (require.main === module) {
  runDailyPull().then(()=>{ console.log('Daily pull done'); process.exit(0) })
  .catch(err=>{ console.error(err); process.exit(1) })
}
